from sqlalchemy import Column, String, Integer, DateTime, ForeignKey,UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from src.config.db import Base
from datetime import datetime
import uuid

class Dataset(Base):
    __tablename__ = "datasets"

    id          = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name        = Column(String, nullable=False)
    size        = Column(Integer, nullable=False)
    r2_path     = Column(String, nullable=False)
    env_id      = Column(UUID(as_uuid=True), ForeignKey("environments.id"), nullable=False)
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    environment = relationship("Environment", back_populates="datasets") 

    __table_args__ = (
        UniqueConstraint("env_id", name="uq_datasets_env_id"),
    )

    def __repr__(self):
        return f"<Dataset id={self.id} name={self.name}>"